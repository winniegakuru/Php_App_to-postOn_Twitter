<?php
// require codebird
require_once('codebird/src/codebird.php');

\Codebird\Codebird::setConsumerKey("yrX1GEfZ6RSLL5Reww2eARTYM", "vSdKG1mBNltSfELqJ8aZ36x0P9ZKAuJWQ6gh57aUgMu1yecToH");
$cb = \Codebird\Codebird::getInstance();
$cb->setToken("1010401764-0N2DDTQdYjFvnWsfBGdX8qlWjgTAZcWdgF9WQeU", "FUe5ZX6l2E3I9Sz8MCseOPjIuAD0KJ83rGeJO11ZPBFku");

echo "<form method='POST' action=''>
<textarea name='message' rows='10' cols='30'>  </textarea>
<input type='submit' name='button1'  value='SEND'>
</form>";

if (isset($_POST['button1']))
{ //$image ='media[]' => 'logo.png'
  $name = $_POST['message'];
    $params = array(
   'status' => $name,'media[]' => 'logo.png');
$reply = $cb->statuses_updateWithMedia($params);
//print_r($reply);
}
?>
